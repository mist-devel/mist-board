This RomVault Dat contains a Clean Set of Atari800 Disk Images for use with the MiST FPGA.
Only Working Games. This Set is based on the Tosec Set. Only ATR & XEX Images.

For those who are familiar with Romvault, just copy the DatRoot and RomRoot Folder from this Zip into your Romvault Directory, copy yor Roms into the ToSort Folder and do the usual work. Once Finished you need to Unzip all Files which Romvault did create. For a Quick Solution with Extractnow Portable, read the Instruction PDF.

----------------------------------------------------------------------------------------
For those who are NOT familiar with RomVault.... PLEASE READ THE INSTRUCTIONS PDF !!!!! 
----------------------------------------------------------------------------------------

Some Basic Instructions for those who are not familiar with the Atari800:
Press F11 to Select Disk Images with the Cursor and press F8 + ENTER at the same time to load and Run the Image.
This will disable BASIC and most Images dont run if you only press ENTER to load a Image.

Important:
ONLY Images who are in a "need Basic" Folder MUST be loaded with BASIC enabled. To do this, simply chose your 
Image with the Cursor Keys and Press ENTER (without the F8 Key pressed).

Sometimes the File Selector freeze after running a Image. You need to reset the MiST then. Also if a Game wont 
recognize the Joystick. Most Times powering the MiST off for a few Seconds will help.

Atari800 Function Keys are: 
F5=HELP, F6=START, F7=SELECT, F8=OPTION
F9=RESET, F10=SYSTEM RESET, F11=Fileselector, F12=CORE Settings (also used to switch Disks !!!)
The LEFT ALT Key enable Scanlines but sadly this will not be saved on SD Card.

Have Fun

Atmosfear




History:
--------
1.5.2017 - First Version based on Tosec

Planned:
--------
add all Files from Odya.net FTP