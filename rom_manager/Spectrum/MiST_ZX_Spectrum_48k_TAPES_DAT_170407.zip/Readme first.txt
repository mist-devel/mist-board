This RomVault Dat contains a Clean Set of ZX Spectrum 48K Tapes for use with the MiST FPGA.
Only Working Tapes. This Set is based on the TOSEC Set.

For those who are familiar with Romvault, just copy the DatRoot and RomRoot Folder from this Zip into your Romvault Directory, copy yor Roms into the ToSort Folder and do the usual work. Once Finished you need to Unzip all Files which Romvault did create. For a Quick Solution with Extractnow Portable, read the Instruction PDF.

----------------------------------------------------------------------------------------
For those who are NOT familiar with RomVault.... PLEASE READ THE INSTRUCTIONS PDF !!!!! 
----------------------------------------------------------------------------------------

Some General Tips for Sorgeligs excellent Core:
Sometimes the Joystick (Always use Kempston) dont work. Switch the Mist off for about 10 Secs will do the Trick. Sometimes it wont work at all. Use Keyboard in those rare cases.
Also sometimes the Game runs to fast. Press F4 to switch back to Normal Mode.

######################
# LOAD and RUN Tapes #
######################

The Spectrum has its very own Keyboard. All Keys also have Functions/Basic Commands on it.
To Simply Load a Tape press the following Keys: J , Shift+Control(STRG)+P, Shift+Control(STRG)+P and ENTER. ( LOAD""+ENTER). Now Press F12 to Enter the OSD from the MiST. Choose LOAD TAPE *.TAP, CSW and choose your TAPE which you want to load and start.
If the Tape is loaded but did not start, you need to start it manualy with RUN+Enter (R+Enter).



Have Fun

Atmosfear




History:
--------
07.04.2017 - First Version based on TOSEC Collection and zxspectrum_20170206.rbf

Planned:
--------
add WOS (World of Spectrum) FTP Archive