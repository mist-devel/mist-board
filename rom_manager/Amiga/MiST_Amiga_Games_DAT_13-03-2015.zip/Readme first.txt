This RomVault Dat contains a Clean Set of Amiga Games for use with the MiST FPGA.
Only Working Games. This Set is based on the Tosec 2014-10-31 Amiga Set
You need these Parts of the Set:
- (TOSEC 2014-10-31) Commodore Sets 05 Amiga Demos Games Others (for Kickstart Disks)
- (TOSEC 2014-10-31) Commodore Sets 04 Amiga Others (for the Save Disks)
- (TOSEC 2014-10-31) Commodore Sets 03 Amiga Games ADF 2-2
- (TOSEC 2014-10-31) Commodore Sets 02 Amiga Games ADF 1-2


For those who are familiar with Romvault, just copy the DatRoot and RomRoot Folder from this Zip into your Romvault Directory, copy yor Roms into the ToSort Folder and do the usual work. Once Finished you need to Unzip all Files which Romvault did create. For a Quick Solution with Extractnow Portable, read the Instruction PDF.

----------------------------------------------------------------------------------------
For those who are NOT familiar with RomVault.... PLEASE READ THE INSTRUCTIONS PDF !!!!! 
----------------------------------------------------------------------------------------

Have Fun

Atmosfear




History:
--------
9.3.2015 - First Version based on Tosec 2014-10-31 Set and Kickstart 1.3

Planned:
--------
Build a Set with AGA Disks for the AGA Core
Build another Set with English Disks instead of German Disks
Build a Set from Compilation Disks
Build a Amiga Demoscene Compilation
Build a Set from Magazine Disks and Cover Disks
Build a Set from PD Disks
Build a Set from Applications
and more...