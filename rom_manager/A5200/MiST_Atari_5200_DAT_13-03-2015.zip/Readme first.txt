This RomVault Dat contains a Clean Set of Atari 5200 Games for use with the MiST FPGA.
Only Working Games. This Set is based on different sources from various Websites. This Set contains Homebrew Games/Demos and also Prototypes and Converted Atari 800 XL Games so they play on a real Atari 5200. AtariAge Forum may be a good start to search for.

Keep in mind that you need to copy the content of the MiST Atari5200 on your SD Card not only the content who is in the subfolder Atar5200 !!! The Folder Atar5200 must be on top of the SD Card !!! 

For those who are familiar with Romvault, just copy the DatRoot and RomRoot Folder from this Zip into your Romvault Directory, copy yor Roms into the ToSort Folder and do the usual work. Once Finished you need to Unzip all Files which Romvault did create. For a Quick Solution with Extractnow Portable, read the Instruction PDF.

----------------------------------------------------------------------------------------
For those who are NOT familiar with RomVault.... PLEASE READ THE INSTRUCTIONS PDF !!!!! 
----------------------------------------------------------------------------------------

Have Fun

Atmosfear




History:
--------
9.3.2015 - First Version based on various Sources

Planned:
--------
nothing