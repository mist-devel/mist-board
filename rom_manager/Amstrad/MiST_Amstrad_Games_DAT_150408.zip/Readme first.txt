This RomVault Dat contains a Clean Set of Amstrad Games for use with the MiST FPGA.
Only Working Games. This Set is based on (TOSEC 2014-10-31) Minor Sets 01 Acorn - Apple.
No Games with 2 or more Disks because the core dont handle diskswapping.
Alot of Games are in France and Spain due the Popularity of the Amstrad CPC Computer in 
these Countries. 
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
In Games with [F-Keys] in Filename need to be pressed F-Key Number rather 
than normal Number in the Trainer Menu or Gamemenu to start the Game.
If this is a bug in the Core or in the Trainer Menu/Game I dont know.
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

CPM Games are normaly loaded via the OSD and startet with the |CPM Command. IF a CPM Game dont 
autoboot then use the CPM Command DIR to get a file listing and run the game simply by typing 
the filename + Enter.

VRam Games 0011 and VRam Games 0111 are normaly loaded via OSD but  must be set accordingly
in the Lower/Upper VRAM Settings in the OSD BEFORE the RUN command.

Example for 0011 VRam Games:

LowerVRAM: X0
LowerVRAM: X0
UpperVRAM: 1X
UpperVRAM: 1X

For those who are familiar with Romvault, just copy the DatRoot and RomRoot Folder from this Zip 
into your Romvault Directory, copy yor Roms into the ToSort Folder and do the usual work. Once 
Finished you need to Unzip all Files which Romvault did create. For a Quick Solution with Extractnow 
Portable, read the Instruction PDF.

The needed Core is now included in the Set. Just rename it to core.rbf. If you use another/newer core,
dont blame me if it breaks compatibility with some Games!

----------------------------------------------------------------------------------------
For those who are NOT familiar with RomVault.... PLEASE READ THE INSTRUCTIONS PDF !!!!! 
----------------------------------------------------------------------------------------

Have Fun

Atmosfear




History:
--------
08.4.2015 - Updated Dat for Core 150331-R3.1. Moved VRAM games into the corresponding directory, added
            more Games and fixed a few. Included the needed core with Permission from Renaud H�lias.
29.3.2015 - Updated Dat for Core 150328-R4, removed varoius Roms for better Game Compatibility, removed 
            Commando & Commando Space Invasion due graphical Glitches. +64 Games.
28.3.2015 - Updated Dat for Core 150318-R3. + 135 Games, +30 CPM Games.
25.3.2015 - First Version based on (TOSEC 2014-10-31) Minor Sets 01 Acorn - Apple.

Planned:
--------
Adding Compilation & PD Disks