This RomVault Dat contains a Clean Set of Amstrad Games for use with the MiST FPGA.
Only Working Games. This Set is based on (TOSEC 2014-10-31) Minor Sets 01 Acorn - Apple
No Games with 2 or more Disks because the core dont handle diskswapping. No CPM Games too.
ALot of Games are in France and Spain due the Popularity of the Amstrad CPC Computer in 
these Countries.


For those who are familiar with Romvault, just copy the DatRoot and RomRoot Folder from this Zip into your Romvault Directory, copy yor Roms into the ToSort Folder and do the usual work. Once Finished you need to Unzip all Files which Romvault did create. For a Quick Solution with Extractnow Portable, read the Instruction PDF.

----------------------------------------------------------------------------------------
For those who are NOT familiar with RomVault.... PLEASE READ THE INSTRUCTIONS PDF !!!!! 
----------------------------------------------------------------------------------------

Have Fun

Atmosfear




History:
--------
25.3.2015 - First Version based on (TOSEC 2014-10-31) Minor Sets 01 Acorn - Apple 

Planned:
--------
Adding Compilation & PD Disks