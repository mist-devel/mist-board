This RomVault Dat contains a Clean Set of Atari 2600 Games for use with the MiST FPGA.
Only Working Games. This Set is based on different sources from various Websites.AtariAge and his Forum may be a good start to search for.

Since i have a set old atari paddles but dont own a 2600-daptor there are no paddle Games in this Set because i can not test em for playability.

For those who are familiar with Romvault, just copy the DatRoot and RomRoot Folder from this Zip into your Romvault Directory, copy yor Roms into the ToSort Folder and do the usual work. Once Finished you need to Unzip all Files which Romvault did create. For a Quick Solution with Extractnow Portable, read the Instruction PDF.

----------------------------------------------------------------------------------------
For those who are NOT familiar with RomVault.... PLEASE READ THE INSTRUCTIONS PDF !!!!! 
----------------------------------------------------------------------------------------

Have Fun

Atmosfear




History:
--------
9.3.2015 - First Version based on various Sources

Planned:
--------
Adding Homebrew Games