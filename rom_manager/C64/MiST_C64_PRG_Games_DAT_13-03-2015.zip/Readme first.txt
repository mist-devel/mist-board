This RomVault Dat contains a Clean Set of C64 PRG Games for use with the MiST FPGA.
Only Working Games and only a Handfull of Dupes. This Set is based on the Tosec 2014-10-31 C64 PRG Set.
This took me Months of Work for renaming and Testing the Games and was a Major Pain in the Ass because the Original Set contains over 18000 Images,
loading and decrunching Games til it runs took some time and more worse, the C64 Core only has a Soft Reset and no Hardreset to clean the Memory. There are so many memory resistent Games and after each memory resistent Game i had to Power off the MiST FPGA, wait aprox 10 seconds to clean the Memory until i can start it again and had to scroll back down the list to the Next game.

For those who are familiar with Romvault, just copy the DatRoot and RomRoot Folder from this Zip into your Romvault Directory, copy the Tosec Set into the ToSort Folder and do the usual work. Once Finished you need to Unzip all Files which Romvault did create. For a Quick Solution with Extractnow Portable, read the Instruction PDF.

----------------------------------------------------------------------------------------
For those who are NOT familiar with RomVault.... PLEASE READ THE INSTRUCTIONS PDF !!!!! 
----------------------------------------------------------------------------------------

Have Fun

Atmosfear



And Remember, NO SAVING or LOADING Gamesaves if a Game ask for it!!! The C64 core lacks Disk/Tape Support :(
The Core also contains some Bugs: Most BASIC Games dont work and did get sortet out. Also F2/F4/F6/F8 keys dont work

History:
--------
9.3.2015 - First Version based on Tosec 2014-10-31 C64 PRG Set

Planned:
--------
- Games made with Shoot em up Construction Kit, Gary Kitchens Gamemaker, Pinball Construction Set will be moved in their own Directory.