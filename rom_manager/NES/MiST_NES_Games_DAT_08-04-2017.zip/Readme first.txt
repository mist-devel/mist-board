This RomVault Dat contains a Clean Set of NES Games for use with the MiST FPGA.
Only Working Games. This Set is based on different sources like Tosec, NoIntro, GoodNES  and various Websites.
This Set contains also Hacked Games where the Game use another Mapper to be playable on the MiST.

For those who are familiar with Romvault, just copy the DatRoot and RomRoot Folder from this Zip into your Romvault Directory, copy yor Roms into the ToSort Folder and do the usual work. Once Finished you need to Unzip all Files which Romvault did create. For a Quick Solution with Extractnow Portable, read the Instruction PDF.

----------------------------------------------------------------------------------------
For those who are NOT familiar with RomVault.... PLEASE READ THE INSTRUCTIONS PDF !!!!! 
----------------------------------------------------------------------------------------

Have Fun

Atmosfear




History:
--------
4.8.2017 - added Trainer Versions, ENG Translationed Games, Demos (approx +900 Roms)
9.3.2015 - First Version based on various Sources

Planned:
--------
nothing