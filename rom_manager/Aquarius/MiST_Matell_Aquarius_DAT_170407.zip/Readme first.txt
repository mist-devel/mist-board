This RomVault Dat contains a Clean Set of Mattel Aquarius Games for use with the MiST FPGA.
Only Working Tapes. This Set is based on the TOSEC Set.

For those who are familiar with Romvault, just copy the DatRoot and RomRoot Folder from this Zip into your Romvault Directory, copy yor Roms into the ToSort Folder and do the usual work. Once Finished you need to Unzip all Files which Romvault did create. For a Quick Solution with Extractnow Portable, read the Instruction PDF.

----------------------------------------------------------------------------------------
For those who are NOT familiar with RomVault.... PLEASE READ THE INSTRUCTIONS PDF !!!!! 
----------------------------------------------------------------------------------------

Use the OSD to Load and Run the Program.



Have Fun

Atmosfear




History:
--------
08.04.2017 - First Version based on TOSEC Collection and core_160908_112119.rbf

Planned:
--------
nothing